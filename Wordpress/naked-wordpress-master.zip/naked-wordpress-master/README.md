naked-wordpress
===============
