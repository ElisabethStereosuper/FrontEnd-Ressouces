<?php get_header(); ?>

	<h1>404</h1>
	<p>Désolée les gars!</p>

<?php get_footer(); ?>